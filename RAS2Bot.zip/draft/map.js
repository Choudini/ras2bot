module.exports = {
    checkMap: function(message) {
        const Discord = require('discord.js');
        var bot = new Discord.Client();
        
}}
    
     
    
    